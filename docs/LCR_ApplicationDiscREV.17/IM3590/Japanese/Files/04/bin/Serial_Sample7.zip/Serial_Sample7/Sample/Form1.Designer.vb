﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'フォームがコンポーネントの一覧をクリーンアップするために dispose をオーバーライドします。
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Windows フォーム デザイナーで必要です。
    Private components As System.ComponentModel.IContainer

    'メモ: 以下のプロシージャは Windows フォーム デザイナーで必要です。
    'Windows フォーム デザイナーを使用して変更できます。  
    'コード エディターを使って変更しないでください。
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.TextBox1 = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.SaveFileDialog1 = New System.Windows.Forms.SaveFileDialog()
        Me.TabControl1 = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.Rbtn_posi = New System.Windows.Forms.RadioButton()
        Me.Rbtn_nega = New System.Windows.Forms.RadioButton()
        Me.Tpage_IM3533 = New System.Windows.Forms.TabPage()
        Me.Rbtn_mono = New System.Windows.Forms.RadioButton()
        Me.Rbtn_color = New System.Windows.Forms.RadioButton()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Tbx_filename = New System.Windows.Forms.TextBox()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.Btn_get = New System.Windows.Forms.Button()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.TabControl1.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        Me.Tpage_IM3533.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'TextBox1
        '
        Me.TextBox1.Location = New System.Drawing.Point(58, 18)
        Me.TextBox1.Name = "TextBox1"
        Me.TextBox1.Size = New System.Drawing.Size(66, 19)
        Me.TextBox1.TabIndex = 0
        Me.TextBox1.Text = "COM1"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 21)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(33, 12)
        Me.Label1.TabIndex = 3
        Me.Label1.Text = "ポート"
        '
        'SaveFileDialog1
        '
        Me.SaveFileDialog1.FileName = "Data"
        Me.SaveFileDialog1.Filter = "CSVファイル(*.csv)|*.csv"
        Me.SaveFileDialog1.RestoreDirectory = True
        '
        'TabControl1
        '
        Me.TabControl1.Controls.Add(Me.TabPage1)
        Me.TabControl1.Controls.Add(Me.Tpage_IM3533)
        Me.TabControl1.Location = New System.Drawing.Point(32, 18)
        Me.TabControl1.Name = "TabControl1"
        Me.TabControl1.SelectedIndex = 0
        Me.TabControl1.Size = New System.Drawing.Size(196, 65)
        Me.TabControl1.TabIndex = 17
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.Rbtn_posi)
        Me.TabPage1.Controls.Add(Me.Rbtn_nega)
        Me.TabPage1.Location = New System.Drawing.Point(4, 21)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(188, 40)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "IM3523"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'Rbtn_posi
        '
        Me.Rbtn_posi.AutoSize = True
        Me.Rbtn_posi.Location = New System.Drawing.Point(88, 14)
        Me.Rbtn_posi.Name = "Rbtn_posi"
        Me.Rbtn_posi.Size = New System.Drawing.Size(64, 16)
        Me.Rbtn_posi.TabIndex = 23
        Me.Rbtn_posi.TabStop = True
        Me.Rbtn_posi.Text = "Positive"
        Me.Rbtn_posi.UseVisualStyleBackColor = True
        '
        'Rbtn_nega
        '
        Me.Rbtn_nega.AutoSize = True
        Me.Rbtn_nega.Checked = True
        Me.Rbtn_nega.Location = New System.Drawing.Point(15, 14)
        Me.Rbtn_nega.Name = "Rbtn_nega"
        Me.Rbtn_nega.Size = New System.Drawing.Size(68, 16)
        Me.Rbtn_nega.TabIndex = 22
        Me.Rbtn_nega.TabStop = True
        Me.Rbtn_nega.Text = "Negative"
        Me.Rbtn_nega.UseVisualStyleBackColor = True
        '
        'Tpage_IM3533
        '
        Me.Tpage_IM3533.Controls.Add(Me.Rbtn_mono)
        Me.Tpage_IM3533.Controls.Add(Me.Rbtn_color)
        Me.Tpage_IM3533.Location = New System.Drawing.Point(4, 21)
        Me.Tpage_IM3533.Name = "Tpage_IM3533"
        Me.Tpage_IM3533.Padding = New System.Windows.Forms.Padding(3)
        Me.Tpage_IM3533.Size = New System.Drawing.Size(188, 40)
        Me.Tpage_IM3533.TabIndex = 1
        Me.Tpage_IM3533.Text = "IM3533,IM3570,IM3590"
        Me.Tpage_IM3533.UseVisualStyleBackColor = True
        '
        'Rbtn_mono
        '
        Me.Rbtn_mono.AutoSize = True
        Me.Rbtn_mono.Location = New System.Drawing.Point(88, 14)
        Me.Rbtn_mono.Name = "Rbtn_mono"
        Me.Rbtn_mono.Size = New System.Drawing.Size(87, 16)
        Me.Rbtn_mono.TabIndex = 23
        Me.Rbtn_mono.TabStop = True
        Me.Rbtn_mono.Text = "Monochrome"
        Me.Rbtn_mono.UseVisualStyleBackColor = True
        '
        'Rbtn_color
        '
        Me.Rbtn_color.AutoSize = True
        Me.Rbtn_color.Checked = True
        Me.Rbtn_color.Location = New System.Drawing.Point(15, 14)
        Me.Rbtn_color.Name = "Rbtn_color"
        Me.Rbtn_color.Size = New System.Drawing.Size(50, 16)
        Me.Rbtn_color.TabIndex = 22
        Me.Rbtn_color.TabStop = True
        Me.Rbtn_color.Text = "Color"
        Me.Rbtn_color.UseVisualStyleBackColor = True
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(21, 101)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(51, 12)
        Me.Label3.TabIndex = 4
        Me.Label3.Text = "ファイル名"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(223, 101)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(28, 12)
        Me.Label4.TabIndex = 6
        Me.Label4.Text = ".bmp"
        '
        'Tbx_filename
        '
        Me.Tbx_filename.Location = New System.Drawing.Point(78, 98)
        Me.Tbx_filename.Name = "Tbx_filename"
        Me.Tbx_filename.Size = New System.Drawing.Size(139, 19)
        Me.Tbx_filename.TabIndex = 5
        Me.Tbx_filename.Text = "Image"
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(63, 185)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(163, 46)
        Me.Button1.TabIndex = 22
        Me.Button1.Text = "保存"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.TabControl1)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Tbx_filename)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Location = New System.Drawing.Point(12, 43)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(268, 136)
        Me.GroupBox1.TabIndex = 26
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "設定"
        '
        'Btn_get
        '
        Me.Btn_get.Enabled = False
        Me.Btn_get.Location = New System.Drawing.Point(65, 197)
        Me.Btn_get.Name = "Btn_get"
        Me.Btn_get.Size = New System.Drawing.Size(163, 46)
        Me.Btn_get.TabIndex = 22
        Me.Btn_get.Text = "保存"
        Me.Btn_get.UseVisualStyleBackColor = True
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(12, 237)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(268, 20)
        Me.ProgressBar1.TabIndex = 27
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(292, 269)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.TextBox1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.TabControl1.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        Me.TabPage1.PerformLayout()
        Me.Tpage_IM3533.ResumeLayout(False)
        Me.Tpage_IM3533.PerformLayout()
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents TextBox1 As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents SaveFileDialog1 As System.Windows.Forms.SaveFileDialog
    Friend WithEvents TabControl1 As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents Tpage_IM3533 As System.Windows.Forms.TabPage
    Friend WithEvents Rbtn_posi As System.Windows.Forms.RadioButton
    Friend WithEvents Rbtn_nega As System.Windows.Forms.RadioButton
    Friend WithEvents Rbtn_mono As System.Windows.Forms.RadioButton
    Friend WithEvents Rbtn_color As System.Windows.Forms.RadioButton
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Tbx_filename As System.Windows.Forms.TextBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents Btn_get As System.Windows.Forms.Button
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar

End Class

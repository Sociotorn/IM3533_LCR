﻿'*******************************************************************************
'このプログラムは、LCRモードでオープン補正、ショート補正を行います。
'[オープン補正の実行]または[ショート補正の実行]を押すと補正値を取得します。
'補正値の取得には時間がかかるため、イベントステータスレジスタのCEMビットを監視し、
'補正が終わるまで待ちます。
'*******************************************************************************

Public Class Form1
    Dim LanSocket As System.Net.Sockets.TcpClient                                           'TCPクライアントsocket
    Dim MsgBuf As String = ""                                                               '受信バッファ

    Enum ESE0
        REF = 128
        COF = 64
        LOF = 32
        MOF = 16
        MUF = 8
        IDX = 4
        EOM = 2
        CEM = 1
    End Enum

    Private Sub Button1_Click_1(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        ExecAdjust("OPEN")
    End Sub

    Private Sub Button2_Click_1(sender As System.Object, e As System.EventArgs) Handles Button2.Click
        ExecAdjust("SHORT")
    End Sub

    Private Sub ExecAdjust(ByVal mode As String)
        Dim ip As System.Net.IPAddress = New System.Net.IPAddress(0)                        'IPアドレス
        Dim port As Integer                                                                 'ポート番号

        Try
            LanSocket = New System.Net.Sockets.TcpClient                                    'TCPインスタンスの生成
            If Not (System.Net.IPAddress.TryParse(TextBox1.Text, ip)) Then
                MsgBox("IPアドレスが正しくありません。")
                Exit Sub
            End If
            port = Convert.ToInt32(TextBox2.Text)
            LanSocket.Connect(ip, port)                                                     '接続

            Button1.Enabled = False
            Button2.Enabled = False

            SendMsg(":MODE LCR")                                                            'モード：LCR
            SendMsg(":TRIGger EXTernal")                                                    'トリガ：外部トリガ
            SendQueryMsg(":ESR0?")                                                          'イベントステータスレジスタの確認
            SendMsg(":CORRection:CALIbration:RETurn ALL")                                   'ALL補正

            Select Case mode
                Case "OPEN"
                    MsgBox("オープン補正を行います。" + vbCrLf + _
                           "フィクスチャがオープン状態になっていることを確認してください。")    '確認メッセージ

                    SendMsg(":CORRection:CALIbration:OPEN ACDC")                                'オープン補正の実行

                Case "SHORT"
                    MsgBox("ショート補正を行います。" + vbCrLf + _
                           "フィクスチャがショート状態になっていることを確認してください。")    '確認メッセージ

                    SendMsg(":CORRection:CALIbration:SHORt ACDC")                               'ショート補正の実行

            End Select

            Do                                                                              '補正完了まで待つ
                SendQueryMsg(":ESR0?")                                                      'イベントステータスレジスタの確認
                If MsgBuf And ESE0.CEM Then                                                 '補正完了ビットを監視
                    Exit Do
                End If
                System.Threading.Thread.Sleep(500)
                System.Windows.Forms.Application.DoEvents()

                If ProgressBar1.Value < ProgressBar1.Maximum Then
                    ProgressBar1.Value += 1                                                 'プログレスバーの処理
                End If
            Loop

            ProgressBar1.Value = ProgressBar1.Maximum

            SendQueryMsg(":CORRection:ERRor?")


            Select Case MsgBuf
                Case "0"
                    MsgBox("校正/補正が正常に終了しました。")

                Case "1"
                    MsgBox("校正/補正がエラー終了しました。")

                Case "2"
                    MsgBox("校正/補正が中断されました。")

            End Select

            ProgressBar1.Value = 0

        Catch Ex As Exception
            MsgBox(Ex.Message)
        End Try

        Try
            LanSocket.Close()                                                               '切断
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try

        Button1.Enabled = True
        Button2.Enabled = True
    End Sub

    Private Sub SendMsg(ByVal strMsg As String)
        Dim SendBuffer As Byte()
        Try
            strMsg = strMsg & vbCrLf
            SendBuffer = System.Text.Encoding.Default.GetBytes(strMsg)
            LanSocket.GetStream.Write(SendBuffer, 0, SendBuffer.Length)                     'メッセージ送信
        Catch Ex As Exception
            MsgBox(Ex.Message)
        End Try
    End Sub

    Private Sub SendQueryMsg(ByVal strMsg As String)
        Dim Length As Integer
        Dim ReceiveBuffer(1) As Byte
        Try
            SendMsg(strMsg)
            Dim Check As Integer
            MsgBuf = Nothing
            Do                                                                              '応答受信まで待つ
                If LanSocket.GetStream.DataAvailable Then
                    Length = LanSocket.GetStream.Read(ReceiveBuffer, 0, 1)
                    Check = ReceiveBuffer(0)
                    If Chr(Check) = vbLf Then
                        Exit Do
                    ElseIf Chr(Check) = vbCr Then
                    Else
                        MsgBuf = MsgBuf & Chr(Check)
                    End If
                End If
            Loop
        Catch Ex As Exception
            MsgBox(Ex.Message)
        End Try
    End Sub

End Class

